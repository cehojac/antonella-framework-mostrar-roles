<?php

namespace PQRST\Admin;
use Jenssegers\Blade\Blade;

class PageAdmin extends Admin
{
    public static function index()
    {
        $blade = new Blade(plugin_dir_path( dirname(__DIR__ )).'resources/views', plugin_dir_path( dirname(__DIR__ )).'storage/cache');
        echo $blade->render('index', ['name' => 'John Doe']);
    }

}
