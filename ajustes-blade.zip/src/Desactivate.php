<?php
namespace PQRST;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
