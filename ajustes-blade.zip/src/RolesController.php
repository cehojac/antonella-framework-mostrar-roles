<?php
    namespace PQRST;
    use Jenssegers\Blade\Blade;
          
    class RolesController
    {
    
        public function __construct()
        {
    
        }
        public static function index()
        {
            $blade = new Blade(plugin_dir_path( dirname(__DIR__ )).'resources/views', plugin_dir_path( dirname(__DIR__ )).'storage/cache');
            $roles = new \WP_Roles;
            echo $blade->render('roles',compact('roles'));
        } 
    }